Main_Optimize_Transmitter_Pose_only_O
save 0228only_O_2;

Main_Optimize_Transmitter_Pose_VOI;
save 0228VOI_2;

pause(10);

Main_Optimize_Transmitter_Pose_1P_MO
save 02281PMO_2;

