/*
 * outfun_PoseError_U_multiOri.h
 *
 * Code generation for function 'outfun_PoseError_U_multiOri'
 *
 */

#ifndef OUTFUN_POSEERROR_U_MULTIORI_H
#define OUTFUN_POSEERROR_U_MULTIORI_H

/* Include files */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "rtwtypes.h"
#include "outfun_PoseError_U_multiOri_types.h"

/* Function Declarations */
extern real_T outfun_PoseError_U_multiOri(const emlrtStack *sp, const real_T x
  [40]);

#ifdef __WATCOMC__

#pragma aux outfun_PoseError_U_multiOri value [8087];

#endif
#endif

/* End of code generation (outfun_PoseError_U_multiOri.h) */
