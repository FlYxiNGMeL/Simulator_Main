%%%%%%%%%%%%%%%%%%% Position and Orientation Estimation Loop %%%%%%%%%%%%c

global Anz_Punkte Anz_Spulen ...
    m funktionscount zeit U Ia ...
    max_abstand ...
    StartX StartY StartZ StartPhi StartTheta 



% Give initial guess
% Flag_guess = [isempty(X_guess) isempty(Y_guess) isempty(Z_guess) isempty(Phi_guess) isempty(Theta_guess)];
% if (Flag_guess(1)==1 || Flag_guess(2)==1 || Flag_guess(3)==1 || Flag_guess(4)==1 || Flag_guess(5)==1)
%     StartX = p(1);
%     StartY = p(2);
%     StartZ = p(3);
%     StartPhi = o(2);
%     StartTheta = o(3);
% else
%     StartX = X_guess;
%     StartY = Y_guess;
%     StartZ = Z_guess;
%     StartPhi = Phi_guess;
%     StartTheta = Theta_guess;
% end


funktionscount=2000;                    % stop option for fsolve functon
Anz_Punkte=1;                           % Number of sensor coils
Anz_Spulen=8;                           % Number of transmitter coils
zeit=0.5;                               % time limitation for fsolve
max_abstand=2;

I_ = Ia;
K_ = pi*N_sende*I_*R_sende^2;            % pre-factor for magnetic dipole
m=zeros(Anz_Spulen,3);

faktor= [1 1 1 1 1 1 1 1]';             % (factor for calibration calculation, here without calibration)
% magnetisches Dipol
phie=oo(1,2);     thetae=oo(1,3);       m(1,:)=faktor(1)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];
phie=oo(2,2);     thetae=oo(2,3);       m(2,:)=faktor(2)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];
phie=oo(3,2);     thetae=oo(3,3);   	m(3,:)=faktor(3)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];
phie=oo(4,2);     thetae=oo(4,3);   	m(4,:)=faktor(4)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];
phie=oo(5,2);     thetae=oo(5,3);       m(5,:)=faktor(5)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];
phie=oo(6,2);     thetae=oo(6,3);   	m(6,:)=faktor(6)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];
phie=oo(7,2);     thetae=oo(7,3);   	m(7,:)=faktor(7)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];
phie=oo(8,2);     thetae=oo(8,3);       m(8,:)=faktor(8)*K_*[sind(thetae)*cosd(phie)      sind(thetae)*sind(phie)        cosd(thetae)];

induceVoltage = U;
[x,y,z,phi,theta]=POS_fix(induceVoltage,StartX,StartY,StartZ,StartPhi,StartTheta);

if phi<=-180
    phi=phi+360;
elseif phi>=180
    phi=phi-360;
end

if theta<=-180
    theta=theta+360;
elseif theta>=180
    theta=theta-360;
end

StartX=x;StartY=y;StartZ=z;StartPhi=phi;StartTheta=theta;


POE=[x,y,z,phi,theta];
POR=[p(1),p(2),p(3),o(2),o(3)];