function [x,y,z,phi,theta]=POS_(U,x,y,z,phi,theta)

[x,y,z,phi,theta,flag]=POS_fast(U,x,y,z,phi,theta);

for i=1:360
    
if flag==0
    StartPhi = StartPhi+1*i;
    [x,y,z,phi,theta,flag]=POS_fast(U,x,y,z,StartPhi,theta);
end

end

if flag==0
    disp('5')
    [x,y,z,phi,theta,flag]=POS_fast(U,x,y,z,StartPhi,theta);
end

